# Custom Accessibility Select Menu

A fully-accessible, custom JavaScript select menu plugin. Requires jQuery v1.4 or later.

Built by Charlie Thomason
